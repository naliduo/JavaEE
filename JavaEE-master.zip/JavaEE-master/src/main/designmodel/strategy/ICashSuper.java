package main.designmodel.strategy;

/**
 * Created by lilk on 2019/1/6.
 */
public interface ICashSuper {
    public double getCashCount(double money);
}
