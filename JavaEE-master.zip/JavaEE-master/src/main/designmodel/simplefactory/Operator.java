package main.designmodel.simplefactory;

/**
 * Created by lilk on 2018/12/31.
 */
public abstract class Operator {
    public int a;
    public int b;

    public Operator() {
    }

    public int getResult() {
        return 0;
    }
}
