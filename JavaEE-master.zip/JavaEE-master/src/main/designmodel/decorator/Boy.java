package main.designmodel.decorator;

/**
 * Created by lilk on 2019/1/7.
 */
public class Boy extends Person {
    public Boy(String name) {
        this.name = name;
    }
}
