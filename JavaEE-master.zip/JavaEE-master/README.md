# JavaEE
some notes and test case for learning JavaEE
